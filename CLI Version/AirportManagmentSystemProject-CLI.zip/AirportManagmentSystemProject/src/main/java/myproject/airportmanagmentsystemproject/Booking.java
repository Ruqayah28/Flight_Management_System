
package myproject.airportmanagmentsystemproject;
import java.util.*;
public class Booking {

    protected static final int EXTRA_LUGGAGE_PRICE = 100;
    protected static final int MEAL_SERVICE_PRICE   = 50;
    protected static final int INSURANCE_PRICE      = 200;
    protected static int bookingCounter = 1001;

    protected int ticketNumber;
    protected boolean hasExtraLuggage;
    protected boolean hasMealService;
    protected boolean hasInsurance;
    protected boolean isFirstClass;
    protected int selectedRow;
    protected int selectedCol;
    protected Flight flight;
    protected String flightTime;

    Scanner input = new Scanner(System.in);

    public Booking() {
        this.flight = null;
        this.flightTime = "";
        this.selectedRow = -1;
        this.selectedCol = -1;
    }

    public int generateTicketNumber() {
        return bookingCounter++;
    }

    public void displaySeatMap() {
        System.out.println("\nSeat Map (0 = Available, X = Reserved):");
        for (int i = 0; i < flight.seats.length; i++) {
            for (int j = 0; j < flight.seats[i].length; j++) {
                System.out.print(flight.seats[i][j] ? "X " : "0 ");
            }
            System.out.println();
        }
    }

public void bookTicket() {
    if (this.flight != null) {
        System.out.println("==================================================================================");
        System.out.println("          There is an existing flight already booked.");
        System.out.println("==================================================================================");
        return;
    }
    int flightType = 0;
    isFirstClass = false;
    System.out.println("==================================================================================");
    System.out.println("                               Booking Process:");
    System.out.println("==================================================================================");
    System.out.println("Select Flight Type:");
    System.out.println("1. Local Flight");
    System.out.println("2. International Flight");
    System.out.println("----------------------------------------------------------------------------------");
    System.out.print("Choose an option: ");
    
    do {
        try {
            flightType = input.nextInt();
            if (flightType != 1 && flightType != 2) {
                System.out.println("Please choose 1 or 2.");
            }
        } catch (Exception e) {
            System.out.println("Invalid input, please enter a number [1 or 2].");
            input.next();
        }
    } while (flightType != 1 && flightType != 2);
    input.nextLine();
    
    int currentTicket = generateTicketNumber();
    if (flightType == 1) {
        flight = LocalFlight.enterSourceAndDestination(input, currentTicket);
        if (flight == null) {
            if (LocalFlight.lastInvalidRoute) {
                System.out.println("Invalid input: source and destination cannot be the same.");
            } else {
                System.out.println("No available flight.");
            }
            return;
        }
    } else {
        flight = InternationalFlight.selectDestination(currentTicket);
        if (flight == null) {
            System.out.println("No available flight.");
            return;
        }
    }
    
    if (flight.status == null || !flight.status.equalsIgnoreCase("Available")) {
        System.out.println("Selected flight is not available for booking.");
        return;
    }
    if (flight.isFlightFull()) {
        System.out.println("This flight is full.");
        flight = null;
        return;
    }
    if (flight instanceof InternationalFlight) {
        System.out.println("Enter your nationality:");
        String nationality = input.nextLine().trim();
        ((InternationalFlight) flight).checkVisa(nationality);
    }
    ticketNumber = currentTicket;
    this.flightTime = flight.getSelectedTime();
    System.out.println("\nFlight time confirmed: " + this.flightTime);
    
    int classChoice = -1;
    System.out.println("\n----------------------------------------------------------------------------------");
    System.out.println("Select Flight Class:");
    System.out.println("1. Economy Class");
    System.out.println("2. First Class");
    System.out.println("----------------------------------------------------------------------------------");
    
    do {
        try {
            classChoice = input.nextInt();
            if (classChoice != 1 && classChoice != 2) {
                System.out.println("Please choose 1 or 2.");
            }
        } catch (Exception e) {
            System.out.println("Invalid input, please enter a number [1 or 2].");
            input.next();
        }
    } while (classChoice != 1 && classChoice != 2);
    isFirstClass = (classChoice == 2);
    input.nextLine();
    
    System.out.println("\nFirst Class: Rows 1-2");
    System.out.println("Economy Class: Rows 3-10");
    displaySeatMap();
    
    boolean seatSelected = false;
    while (!seatSelected) {
        System.out.println("\nEnter row number (1-10):");
        selectedRow = input.nextInt() - 1;
        System.out.println("Enter seat number (1-7):");
        selectedCol = input.nextInt() - 1;
        input.nextLine();
        if (isFirstClass && selectedRow >= 2) {
            System.out.println("First class seats are only available in rows 1-2.");
            continue;
        } else if (!isFirstClass && selectedRow < 2) {
            System.out.println("Economy class seats are only available in rows 3-10.");
            continue;
        }
        if (flight.reserveSeat(selectedRow, selectedCol)) {
            seatSelected = true;
        } else {
            System.out.println("This seat is already booked. Please select another seat.");
        }
    }
    if (!isFirstClass) {
        extraServices();
    } else {
        hasExtraLuggage = true;
        hasMealService  = true;
        hasInsurance    = true;
    }
}

    public void extraServices() {
        System.out.println("----------------------------------------------------------------------------------");
        System.out.println("\nEnter your luggage weight in KG:");
        int weight = input.nextInt();
        input.nextLine();
        boolean isOverweight = flight.checkWeight(weight);
        if (isOverweight) {
            while (true) {
                System.out.println("\nYour luggage are overweight. Would you like extra luggage weight? (yes/no)");
                String answer = input.nextLine().toLowerCase();
                if (answer.equals("yes")) {
                    hasExtraLuggage = true;
                    break;
                } else if (answer.equals("no")) {
                    System.out.println("You must pay for extra weight luggage to continue booking.");
                } else {
                    System.out.println("Invalid input. Please type 'yes' or 'no'.");
                }
            }
        } else {
            hasExtraLuggage = false;
        }
        String answer;
        do {
            System.out.println("Would you like meal service? (yes/no)");
            answer = input.nextLine().toLowerCase();
        } while (!answer.equals("yes") && !answer.equals("no"));
        hasMealService = answer.equals("yes");
        do {
            System.out.println("Would you like insurance? (yes/no)");
            answer = input.nextLine().toLowerCase();
        } while (!answer.equals("yes") && !answer.equals("no"));
        hasInsurance = answer.equals("yes");
    }

    public double calculateTotalCost() {
        double cost;
        if (isFirstClass) {
            cost = 1000 + (1000 * FirstClass.additionalFee);
        } else {
            cost = 500;
            if (hasExtraLuggage) cost += EXTRA_LUGGAGE_PRICE;
            if (hasMealService)  cost += MEAL_SERVICE_PRICE;
            if (hasInsurance)    cost += INSURANCE_PRICE;
        }
        if (flight instanceof InternationalFlight) {
            InternationalFlight intFlight = (InternationalFlight) flight;
            if (intFlight.isVisaRequired()) {
                cost += 100;
            }
        }
        if (!isFirstClass) {
        cost = Economy.applyEconomyDiscount(cost);
        }
        return cost;
    }

    public void viewBookingDetails() {
        double totalCost = calculateTotalCost();
        System.out.println("\t\t\tTicket Number: " + "TIC-"+ ticketNumber);
        System.out.println("\t\t\tFlight Number: " + flight.getFlightNumber());
        System.out.println("\t\t\tFlight: from " + flight.source + " to " + flight.destination);
        System.out.println("\t\t\tFlight Time: " + flightTime);
        System.out.println("\t\t\tClass: " + (isFirstClass ? "First Class" : "Economy"));
        System.out.println("\t\t\tExtra Luggage: " + (hasExtraLuggage ? "Yes" : "No"));
        System.out.println("\t\t\tMeal Service: " + (hasMealService ? "Yes" : "No"));
        System.out.println("\t\t\tInsurance: " + (hasInsurance ? "Yes" : "No"));
        System.out.println("\t\t\tTotal Cost: $" + totalCost);
        System.out.println("----------------------------------------------------------------------------------\n");
    }
}