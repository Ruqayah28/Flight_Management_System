
package myproject.airportmanagmentsystemproject;

public class Economy extends Booking {
    public static double specialDiscount = 0.20;

    public Economy(boolean hasExtraLuggage, boolean hasMealService, boolean hasInsurance) {
        super();
        this.ticketNumber = generateTicketNumber();
        this.isFirstClass = false;
        this.hasExtraLuggage = hasExtraLuggage;
        this.hasMealService = hasMealService;
        this.hasInsurance = hasInsurance;
    }
    public static double applyEconomyDiscount(double originalPrice) {
        return originalPrice - (originalPrice * specialDiscount);
    }
}
