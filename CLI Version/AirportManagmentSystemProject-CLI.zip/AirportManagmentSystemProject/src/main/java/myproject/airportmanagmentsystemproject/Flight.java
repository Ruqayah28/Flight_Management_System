
package myproject.airportmanagmentsystemproject;
import java.util.*;

public class Flight {
    protected String source;
    protected String destination;
    protected int passengerCount;
    protected int availableSeats;
    protected String status;
    public boolean[][] seats;
    protected String flightNumber;
    protected String selectedTime;

    public Flight(String source, String destination, int seats) {
        this.source = source;
        this.destination = destination;
        this.availableSeats = 70; 
        this.seats = new boolean[10][7];
    }

    public void updateStatus(String status) {
        this.status = status;
    }
    
    public void setSelectedTime(String time) {
        this.selectedTime = time;
    }
    
    public String getSelectedTime() {
        return selectedTime;
    }
    
    public String getFlightNumber() {
        return flightNumber;
    }
    
    public void displayFlightInfo() {
        System.out.println("   Flight Number: " + flightNumber + " | Source: " + source  + " | Destination: " + destination  + " | Time: " + selectedTime);
    }
    public List<String> getAvailableTimes() {
    return new ArrayList<>();
}
    
    public boolean checkWeight(int luggageWeight) {
        int normalWeight = 25;
        if (luggageWeight > normalWeight) {
            int over = luggageWeight - normalWeight;
            System.out.println("Luggage overweight! You have " + over + " Kg over the limit.");
            return true;
        }
        return false;
    }
    

    
public boolean reserveSeat(int row, int col) {
    if (row < 0 || row >= seats.length || col < 0 || col >= seats[row].length || seats[row][col]) {
        System.out.println("Invalid seat selection or seat already taken.");
        return false;
    }
    seats[row][col] = true;
    passengerCount++;
    availableSeats--;
    System.out.println("Seat in row " + (row + 1) + " and column " + (col + 1) + " reserved successfully.");

    if (availableSeats <= 0) {
        updateStatus("Full");
    }
    return true;
}
    
    public boolean isFlightFull() {
        for (int i = 0; i < seats.length; i++) {
            for (int j = 0; j < seats[i].length; j++) {
                if (!seats[i][j]) return false;
            }
        }
        return true;
    }
}