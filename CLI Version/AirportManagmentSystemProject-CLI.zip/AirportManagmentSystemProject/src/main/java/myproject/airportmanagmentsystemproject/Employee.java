
package myproject.airportmanagmentsystemproject;

import java.util.ArrayList;


public class Employee extends User {
    public static ArrayList<Employee> employees = new ArrayList<>();
    
    public Employee() {
         super(false);
         this.password = User.inputPassword();
    }
    
    public static void addNewEmployee() {
        Employee newEmployee = new Employee();
        
        for (Employee employee : Employee.employees) {
            if (employee.getId().equals(newEmployee.getId())) {
                System.out.println("------------------------------------------------------------------------------");
                System.out.println("                  Employee with ID " + newEmployee.getId() + " already exists!!         ");
                System.out.println("------------------------------------------------------------------------------");    
                return;  
            }
        }
        Employee.employees.add(newEmployee);
        System.out.println("------------------------------------------------------------------------------");
        System.out.println("                         Employee Added Successfully");
        System.out.println("------------------------------------------------------------------------------");
    }

    
    public static void listAllEmployees() {
        if (Employee.employees.isEmpty()) {
            System.out.println("No employees found.");
        } else {
            System.out.println("Employee List:");
            int count = 1;
            for (Employee employee : Employee.employees) {
                System.out.println("Employee " + count + ": " + employee.getName());
                count++;
            }
        }
    }

    @Override
    public void displayInfo() {
        System.out.println("Employee Information:");
        System.out.println("Name: " + name);
        System.out.println("ID: " + id);
    }
}
