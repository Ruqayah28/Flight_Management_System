
package myproject.airportmanagmentsystemproject;
import java.util.*;

public class InternationalFlight extends Flight {
     static Scanner input = new Scanner(System.in);
    private boolean visaRequired;
    private static List<InternationalFlight> allInternationalFlights = new ArrayList<>();
    private static final List<String> availableDestinations = List.of(
        "UAE", "EGY", "USA", "UK", "GER", "AUS", "IND", "FRA", "TUR", "SWI"
    );
    //Constructor
    public InternationalFlight(String flightNumber, String destination, int totalSeats, String selectedTime) {
    super("SAU", destination, 70);
    if (!availableDestinations.contains(destination.toUpperCase())) {
        throw new IllegalArgumentException("Invalid destination");
    }
    this.flightNumber = flightNumber;
    this.destination = destination.toUpperCase();
    this.selectedTime = selectedTime;
    allInternationalFlights.add(this);
}
    //This method returns an array of available flight times for a given destination.
    public static String[] getPossibleTimes(String destination) {
        switch (destination.toUpperCase()) {
            case "UAE":
                return new String[]{"7:15 AM", "6:00 PM", "11:30 PM"};
            case "EGY":
                return new String[]{"8:00 PM", "2:00 PM", "9:00 PM"};
            case "USA":
                return new String[]{"8:00 AM", "6:45 AM", "10:00 AM"};
            case "UK": 
                return new String[]{"3:30 AM", "5:30 PM", "9:00 PM"};
            case "GER":
                return new String[]{"8:30 AM", "2:00 PM", "1:00 PM"};
            case "AUS":
                return new String[]{"3:00 AM", "8:00 PM", "11:00 PM"};
            case "IND":
                return new String[]{"5:00 AM", "2:30 PM", "10:00 PM"};
            case "FRA":
                return new String[]{"8:00 AM", "5:00 PM", "9:00 PM"};
            case "TUR":
                return new String[]{"8:00 PM", "12:00 PM", "9:00 AM"};
            case "SWI":
                return new String[]{"9:00 AM", "3:00 PM", "10:00 PM"};
            default:
                System.out.println("Invalid destination airport code");
                return new String[]{};
        }
    }
    //This method returns a list containing the selected time for the flight.
    public List<String> getAvailableTimes() {
        List<String> list = new ArrayList<>();
        list.add(selectedTime);
        return list;
    }
     
  //This method allows the user to select a destination and returns a matching destination.
public static InternationalFlight selectDestination( int ticketNumber) {
    String destination = getDestinationInput("Enter destination airport code (UAE, EGY, USA, UK, GER, AUS, IND, FRA, TUR, SWI): ");
    System.out.println("Selected Destination: " + destination);
    List<InternationalFlight> matching = new ArrayList<>();
    for (InternationalFlight flight : allInternationalFlights) {
        if (flight.destination.equalsIgnoreCase(destination)
                && "Available".equalsIgnoreCase(flight.status)
                && !flight.isFlightFull()) {
            matching.add(flight);
        }
    }
    if (matching.isEmpty()) {
        return null;
    }
    if (matching.size() == 1) {
        return matching.get(0);
    }
    System.out.println("Multiple flights available for this destination:");
    for (int i = 0; i < matching.size(); i++) {
        System.out.println((i + 1) + "- Flight Number: " + matching.get(i).getFlightNumber()
                + " | Time: " + matching.get(i).getSelectedTime());
    }
    System.out.print("Enter the number of the flight you want: ");
    int choice = -1;
    try {
        choice = Integer.parseInt(input.nextLine());
    } catch (NumberFormatException e) {
        System.out.println("Invalid input");
        return null;
    }

    if (choice < 1 || choice > matching.size()) {
        System.out.println("Invalid choice");
        return null;
    }
    return matching.get(choice - 1);
}
//This method adds a new flights to the system.
public static void addInternationalFlight() {
    String destination = getDestinationInput("Enter destination country (UAE, EGY, USA, UK, GER, AUS, IND, FRA, TUR, SWI): ");

    String[] possibleTimes = getPossibleTimes(destination);
    if (possibleTimes.length == 0) {
        System.out.println("No times available for that destination");
        return;
    }
    System.out.println("Pick a flight time for " + destination + ":");
    for (int i = 0; i < possibleTimes.length; i++) {
        System.out.println((i + 1) + "-" + possibleTimes[i]);
    }
    System.out.print("Enter choice:  ");
    int timeChoice = -1;
    try {
        timeChoice = Integer.parseInt(input.nextLine());
    } catch (NumberFormatException e) {
        System.out.println("Invalid input");
        return;
    }
    if (timeChoice < 1 || timeChoice > possibleTimes.length) {
        System.out.println("Invalid time choice");
        return;
    }
    String chosenTime = possibleTimes[timeChoice - 1];
    for (InternationalFlight flight : allInternationalFlights) {
        if (flight.destination.equalsIgnoreCase(destination)
            && chosenTime.equalsIgnoreCase(flight.getSelectedTime())
            && "Available".equalsIgnoreCase(flight.status)) {
            System.out.println("==============================================================================");
            System.out.println("                 Flight Already Exists with that time!");
            System.out.println("==============================================================================");
            return;  
        }
    }
    String flightNumber = "INTER" + (100 + new Random().nextInt(900));
    InternationalFlight newFlight = new InternationalFlight(flightNumber, destination, 70, chosenTime);
    newFlight.updateStatus("Available");

    System.out.println("==============================================================================");
    System.out.println("                Flight Added Successfully with time " + chosenTime);
    System.out.println("==============================================================================");
    newFlight.displayFlightInfo();
}

    //This method ask the user to enter a destination and ensuring the input is valid.
    public static String getDestinationInput(String prompt) {
        String dest;
        while (true) {
            System.out.println(prompt);
            dest = input.nextLine().toUpperCase();
            if (availableDestinations.contains(dest)) break;
            System.out.println("Invalid destination!Try again");
        }
        return dest;
    }
    public static List<InternationalFlight> getAllInternationalFlights() {
        return allInternationalFlights;
    }
// This method checks if the user requires a visa for their travel based on their nationality and destination.
public void checkVisa(String nationality) {
    nationality = nationality.toUpperCase();
    if ("SAUDI".equals(nationality)
            && (destination.equalsIgnoreCase("UAE") || destination.equalsIgnoreCase("EGY"))) {
        visaRequired = false;
        System.out.println("No Need For VISA since you are " + nationality + " traveling to " + destination.toUpperCase());
    } else {
        visaRequired = true;
        System.out.println("Visa is required for " + nationality + " traveling to " + destination.toUpperCase());
        promptVisaNumber();
    }
}
    // This method ask the user to enter their visa number and check that it is exactly 10 digits.
private void promptVisaNumber() {
    while (true) {
        System.out.println("Enter your Visa Number (10 digits):");
        String visaInput = input.nextLine();
        
        if (visaInput.length()==10) {
            break; 
        } else {
            System.out.println("Invalid Visa Number! It must be exactly 10 digits");
        }
    }
}
    //This method returns whether a visa is required for the flight.
    public boolean isVisaRequired() {
        return visaRequired;
    }
    //This overridden method checks if the flight is full.
    @Override
    public boolean isFlightFull() {
        return availableSeats <= 0;
    }

}