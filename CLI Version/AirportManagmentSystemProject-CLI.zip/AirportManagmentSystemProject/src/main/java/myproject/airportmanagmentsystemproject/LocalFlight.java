
package myproject.airportmanagmentsystemproject;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Random;

import java.util.Scanner;


public class LocalFlight extends Flight {
    private static List<LocalFlight> allLocalFlights = new ArrayList<>();
    private static final List<String> availableAirports = Arrays.asList("JED", "RUH", "NUM", "MED", "BHH", "DMM", "AQI", "AHB", "TUU", "AJF");
    public static boolean lastInvalidRoute = false;

public LocalFlight(String source, String destination, String flightNumber, String selectedTime) {
    super(source, destination, 70);
    if (!availableAirports.contains(source) || !availableAirports.contains(destination)) {
        throw new IllegalArgumentException("Invalid airport code.");
    }
    this.flightNumber = flightNumber;
    this.selectedTime = selectedTime;
    allLocalFlights.add(this);
}
    
    public static String[] getPossibleTimes(String destination) {
        switch (destination.toUpperCase()) {
            case "JED":
                return new String[]{"6:00 AM", "12:00 PM", "9:30 PM"};
            case "RUH":
                return new String[]{"7:15 AM", "2:00 PM", "9:30 PM"};
            case "DMM":
                return new String[]{"8:00 AM", "2:30 PM", "9:00 PM"};
            case "NUM":
                return new String[]{"5:00 AM", "3:00 PM", "9:30 PM"};
            case "MED":
                return new String[]{"6:45 AM", "2:15 PM", "9:45 PM"};
            case "BHH":
                return new String[]{"7:30 AM", "3:00 PM", "10:30 PM"};
            case "AQI":
                return new String[]{"6:15 AM", "1:45 PM", "9:15 PM"};
            case "TUU":
                return new String[]{"6:40 AM", "1:10 PM", "8:40 PM"};
            case "AHB":
                return new String[]{"7:10 AM", "2:40 PM", "9:10 PM"};
            case "AJF":
                return new String[]{"7:20 AM", "2:50 PM", "10:20 PM"};
            default:
                System.out.println("Invalid destination airport code.");
                return new String[]{};
        }
    }
        public List<String> getAvailableTimes() {
        List<String> list = new ArrayList<>();
        list.add(selectedTime);
        return list;
    }
    

    public static LocalFlight enterSourceAndDestination(Scanner scanner, int ticketNumber) {
    lastInvalidRoute = false;

    String source = getAirportInput(scanner,
            "Enter source airport code (JED, RUH, NUM, MED, BHH, DMM, AQI, AHB, TUU, AJF): ");
    String destination = getAirportInput(scanner,
            "Enter destination airport code (JED, RUH, NUM, MED, BHH, DMM, AQI, AHB, TUU, AJF): ");

    if (source.equals(destination)) {
        lastInvalidRoute = true;
        return null;
    }

    System.out.println("Source: " + source + " -> Destination: " + destination);
    
    List<LocalFlight> matching = new ArrayList<>();
    for (LocalFlight flight : allLocalFlights) {
        if (flight.source.equals(source)
                && flight.destination.equals(destination)
                && "Available".equalsIgnoreCase(flight.status)
                && !flight.isFlightFull()) {
            matching.add(flight);
        }
    }

    if (matching.isEmpty()) {
        return null;
    }

    if (matching.size() == 1) {
        return matching.get(0);
    }

    System.out.println("Multiple flights available for this route:");
    for (int i = 0; i < matching.size(); i++) {
        System.out.println((i + 1) + ". Flight Number: " + matching.get(i).getFlightNumber()
                + " | Time: " + matching.get(i).getSelectedTime());
    }

    System.out.print("Enter the number of the flight you want: ");
    int choice = -1;
    try {
        choice = Integer.parseInt(scanner.nextLine());
    } catch (NumberFormatException e) {
        System.out.println("Invalid input.");
        return null;
    }

    if (choice < 1 || choice > matching.size()) {
        System.out.println("Invalid choice.");
        return null;
    }

    return matching.get(choice - 1);
}

    public static void addLocalFlight(Scanner scanner) {
        String source, destination;
        do {
            source = getAirportInput(scanner, "Enter source airport code (JED, RUH, NUM, MED, BHH, DMM, AQI, AHB, TUU, AJF): ");
            destination = getAirportInput(scanner, "Enter destination airport code (JED, RUH, NUM, MED, BHH, DMM, AQI, AHB, TUU, AJF): ");
            if (source.equals(destination)) {
                System.out.println("Error: Source and destination cannot be the same. Please enter again.");
            }
        } while (source.equals(destination));
        
        String[] possibleTimes = getPossibleTimes(destination);
        if (possibleTimes.length == 0) {
            System.out.println("No times available for that destination.");
            return;
        }
        System.out.println("Pick a flight time for this route:");
        for (int i = 0; i < possibleTimes.length; i++) {
            System.out.println((i+1) + ". " + possibleTimes[i]);
        }
        System.out.print("Enter choice ");
        int timeChoice = -1;
        try {
            timeChoice = Integer.parseInt(scanner.nextLine());
        } catch (NumberFormatException e) {
            System.out.println("Invalid input.");
            return;
        }
        if (timeChoice < 1 || timeChoice > possibleTimes.length) {
            System.out.println("Invalid time choice.");
            return;
        }
        String chosenTime = possibleTimes[timeChoice - 1];
        
        for (LocalFlight flight : allLocalFlights) {
            if (flight.source.equals(source) && flight.destination.equals(destination)
                && chosenTime.equalsIgnoreCase(flight.getSelectedTime())) {
                if ("Available".equalsIgnoreCase(flight.status)) {
                    System.out.println("==============================================================================");
                    System.out.println("                 Flight Already Exists with that time!"                      );
                    System.out.println("==============================================================================");
                    return;
                }
            }
        }
        
        String flightNumber = "LOCAL" + (100 + new Random().nextInt(900));
        LocalFlight newFlight = new LocalFlight(source, destination, flightNumber, chosenTime);
        newFlight.updateStatus("Available");
        System.out.println("==============================================================================");
        System.out.println("                    Flight Added Successfully with time " + chosenTime);
        System.out.println("==============================================================================");
        newFlight.displayFlightInfo();
    }
    
    public static String getAirportInput(Scanner scanner, String prompt) {
        String airportCode;
        while (true) {
            System.out.println(prompt);
            airportCode = scanner.nextLine().toUpperCase();
            if (availableAirports.contains(airportCode)) break;
            System.out.println("Invalid airport code. Try again.");
        }
        return airportCode;
    }
    
    public static List<LocalFlight> getAllLocalFlights() {
        return allLocalFlights;
    }
    
    public static void listFlightsFromSourceToDestination(String source, String destination) {
        boolean found = false;
        for (LocalFlight flight : allLocalFlights) {
            if (flight.source.equals(source) && flight.destination.equals(destination)) {
                System.out.println("Flight Number: " + flight.getFlightNumber()
                    + " | Time: " + flight.getSelectedTime());
                found = true;
            }
        }
        if (!found) {
            System.out.println("================================================================================");
            System.out.println("                       No Available Flights from "+source+ " to " + destination);
            System.out.println("================================================================================");
        }
    }
}
