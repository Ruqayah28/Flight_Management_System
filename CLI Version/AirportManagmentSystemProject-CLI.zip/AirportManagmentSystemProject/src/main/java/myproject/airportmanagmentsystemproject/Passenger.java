
package myproject.airportmanagmentsystemproject;

import java.util.Scanner;

public class Passenger extends User {
    private String phoneNumber;
    private String email;

    public Passenger() {
        super(true);
        this.id = passportInput(); 
        this.phoneNumber = inputPhoneNumber();
        this.password = User.inputPassword();
        this.email = inputEmail();
    }

    private static String passportInput() {
        Scanner sc = new Scanner(System.in);
        String passport;
        while (true) {
            System.out.print("Enter Passport (2 letters followed by 6 digits): ");
            passport = sc.nextLine().trim().toUpperCase();
            if (passport.matches("[A-Z]{2}\\d{6}")) {
                break;
            }
            System.out.println("Invalid input: Passport must start with 2 letters followed by 6 digits.");
        }
        return passport;
    }
    
    private static String inputPhoneNumber() {
        Scanner sc = new Scanner(System.in);
        String phone;
        while (true) {
            System.out.print("Enter Phone Number (10 digits): ");
            phone = sc.nextLine().trim();
            if (phone.matches("\\d{10}")) {
                break;
            }
            System.out.println("Invalid input: Phone number must be exactly 10 digits.");
        }
        return phone;
    }
    
    private static String inputEmail() {
        Scanner sc = new Scanner(System.in);
        String email;
        while (true) {
            System.out.print("Enter Email: ");
            email = sc.nextLine().trim();
            if (email.matches("[a-zA-Z0-9]+@gmail.com")) {
                break;
            }
            System.out.println("Invalid email format. Please try again.");
        }
        return email;
    }
    

    public void updateProfile() {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter new phone number : ");
        String newPhone = sc.nextLine().trim();
        if (!newPhone.isEmpty()) {
            if(newPhone.matches("\\d{10}")) {
                phoneNumber = newPhone;
            } else {
                System.out.println("Invalid phone number. Must be 10 digits.");
            }
        }
        System.out.print("Enter new password : ");
        String newPass = sc.nextLine().trim();
        if (!newPass.isEmpty()) {
            int letters = 0, digits = 0;
            for (char c: newPass.toCharArray()){
                if (Character.isLetter(c)) letters++;
                else if (Character.isDigit(c)) digits++;
            }
            if (letters >= 6 && digits >= 2) {
                password = Character.toUpperCase(newPass.charAt(0)) + newPass.substring(1);
            } else {
                System.out.println("Invalid password.");
            }
        }
        System.out.print("Enter new email : ");
        String newEmail = sc.nextLine().trim();
        if (!newEmail.isEmpty()) {
            if(newEmail.matches("^\\S+@\\S+\\.\\S+$")){
                email = newEmail;
            } else {
                System.out.println("Invalid email format.");
            }
        }
    }
    
    public void displayInfo(boolean bookingMode) {
        if (bookingMode) {
            System.out.println("==================================================================================");
            System.out.println("                          Flight booked successfully!                           ");
            System.out.println("==================================================================================");
            System.out.println("----------------------------------------------------------------------------------");
        } else {
            System.out.println("==================================================================================");
            System.out.println("                               Updated Profile                                    ");
            System.out.println("==================================================================================");
            System.out.println("----------------------------------------------------------------------------------");
        }
        System.out.println("\t\t\tName: " + name);
        System.out.println("\t\t\tPassport: " + id);
        System.out.println("\t\t\tPhone Number: " + phoneNumber);
        System.out.println("\t\t\tEmail: " + email);
    }
}
