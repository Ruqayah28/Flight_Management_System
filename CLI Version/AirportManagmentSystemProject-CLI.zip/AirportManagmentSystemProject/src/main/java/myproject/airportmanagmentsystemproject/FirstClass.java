
package myproject.airportmanagmentsystemproject;

public class FirstClass extends Booking {

    protected final static double additionalFee = 0.05;

    public FirstClass(boolean hasExtraLuggage, boolean hasMealService, boolean hasInsurance) {
        super();
        this.ticketNumber = generateTicketNumber();
        this.isFirstClass = true;
        this.hasExtraLuggage = true;
        this.hasMealService = true;
        this.hasInsurance   = true;
    }
}