
package myproject.airportmanagmentsystemproject;
import java.util.Scanner;
import java.util.*;

public class AirportManagmentSystemProject {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Booking currentBooking = null;

        System.out.println("==================================================================================");
        System.out.println("==================== Welcome To Our Airport Management System ====================");
        System.out.println("===================== Help our team to find your best choice =====================");
        System.out.println("========================= Select your Role to proceed ============================");
        System.out.println("==================================================================================");

        while (true) {
            System.out.println("\n----------------------------------------------------------------------------------");
            System.out.println("1. Employee");
            System.out.println("2. Passenger");
            System.out.println("3. Exit");
            System.out.println("----------------------------------------------------------------------------------");
            System.out.print("Your choice: ");

            int roleChoice = -1;
            try {
                roleChoice = scanner.nextInt();
                scanner.nextLine();
            } catch (InputMismatchException e) {
                System.out.println("Invalid input. Please enter a number (1, 2, or 3).");
                scanner.nextLine();
                continue;
            }
            
            switch (roleChoice) {
                case 1: {
                    boolean employeeLoggedIn = true;
                    Employee employee = new Employee();
                    
                    while (employeeLoggedIn) {
                        System.out.println("==============================================================================");
                        System.out.println("                              Employee Management");
                        System.out.println("==============================================================================");
                        System.out.println("1. Manage Flights");
                        System.out.println("2. Manage Employee Information");
                        System.out.println("3. Go Back");
                        System.out.println("---------------------");
                        System.out.print("Enter your choice: ");
                        
                        int employeeChoice = -1;
                        try {
                            employeeChoice = scanner.nextInt();
                            scanner.nextLine();
                        } catch (InputMismatchException e) {
                            System.out.println("Invalid input, please enter (1, 2, or 3).");
                            scanner.nextLine();
                            continue;
                        }
                        
                        switch (employeeChoice) {
                            case 1:
                                manageFlights(scanner);
                                break;
                            case 2:
                                manageEmployeeInfo(scanner);
                                break;
                            case 3:
                                employeeLoggedIn = false;
                                break;
                            default:
                                System.out.println("Invalid choice, please try again.");
                                break;
                        }
                    }
                    break;
                }
                case 2: {
                    boolean passengerLoggedIn = true;
                    Passenger passenger = new Passenger();

                    while (passengerLoggedIn) {
                        System.out.println("==================================================================================");
                        System.out.println("                                Passenger Menu:                                   ");
                        System.out.println("==================================================================================");
                        System.out.println("1. Book flight");
                        System.out.println("2. Profile");
                        System.out.println("3. Logout");
                        System.out.println("----------------------------------------------------------------------------------");
                        System.out.print("Choose an option: ");

                        int passengerChoice = -1;
                        try {
                            passengerChoice = scanner.nextInt();
                            scanner.nextLine();
                        } catch (InputMismatchException e) {
                            System.out.println("Invalid input. Please enter a number from 1 to 3.");
                            scanner.nextLine();
                            continue;
                        }
                        switch (passengerChoice) {
                            case 1:
                                if (currentBooking != null && currentBooking.flight != null) {
                                    System.out.println("==================================================================================");
                                    System.out.println("                        There is an existing booking.                             ");
                                    System.out.println("==================================================================================");
                                } else {
                                    if (currentBooking == null) {
                                        currentBooking = new Booking();
                                    }
                                    currentBooking.bookTicket();
                                    if (currentBooking.flight != null) {
                                        passenger.displayInfo(true);
                                        currentBooking.viewBookingDetails();
                                    }
                                }
                                break;
                            case 2: {
                                boolean inProfileMenu = true;
                                while (inProfileMenu) {
                                    System.out.println("==================================================================================");
                                    System.out.println("                                Profile Menu                                      ");
                                    System.out.println("==================================================================================");
                                    System.out.println("1. Update Profile");
                                    System.out.println("2. Go Back");
                                    System.out.print("Enter your choice: ");
                                    int profileChoice = -1;
                                    try {
                                        profileChoice = scanner.nextInt();
                                        scanner.nextLine();
                                    } catch (InputMismatchException e) {
                                        System.out.println("Invalid input. Please enter 1 or 2.");
                                        scanner.nextLine();
                                        continue;
                                    }
                                    switch (profileChoice) {
                                        case 1:
                                            passenger.updateProfile();
                                            passenger.displayInfo(false);
                                            break;
                                        case 2:
                                            inProfileMenu = false;
                                            break;
                                        default:
                                            System.out.println("Invalid choice, please try again.");
                                    }
                                }
                                break;
                            }
                            case 3:
                                passengerLoggedIn = false;
                                currentBooking = null;
                                break;
                            default:
                                System.out.println("Invalid choice, please try again.");
                                break;
                        }
                    }
                    break;
                }
                case 3:
                    System.out.println("Thank you for using our Airport Management System. Goodbye!");
                    System.exit(0);
                default:
                    System.out.println("Invalid choice, please try again.");
            }
        }
    }
    
    private static void manageFlights(Scanner scanner) {
        boolean managingFlights = true;
        while (managingFlights) {
            System.out.println("==============================================================================");
            System.out.println("                                 Flight Menu");
            System.out.println("==============================================================================");
            System.out.println("1. Add Local Flight");
            System.out.println("2. Add International Flight");
            System.out.println("3. Cancel Flight");
            System.out.println("4. Go Back");
            System.out.print("Enter your choice: ");
            
            int choice = -1;
            try {
                choice = scanner.nextInt();
                scanner.nextLine();
            } catch (InputMismatchException e) {
                System.out.println("Invalid input, please enter a number from 1 to 4.");
                scanner.nextLine();
                continue;
            }
            switch (choice) {
                case 1:
                    LocalFlight.addLocalFlight(scanner);
                    break;
                case 2:
                    InternationalFlight.addInternationalFlight();
                    break;
                case 3:
                    cancelFlight(scanner);
                    break;
                case 4:
                    managingFlights = false;
                    break;
                default:
                    System.out.println("Invalid choice.");
            }
        }
    }
    
    private static void manageEmployeeInfo(Scanner scanner) {
        boolean managingEmployeeInfo = true;
        while (managingEmployeeInfo) {
            System.out.println("==============================================================================");
            System.out.println("                         Employee Information Management");
            System.out.println("==============================================================================");
            System.out.println("1. Add New Employee");
            System.out.println("2. List All Employees");
            System.out.println("3. Go Back");
            System.out.println("---------------------");
            System.out.print("Enter your choice: ");
            
            int choice = -1;
            try {
                choice = scanner.nextInt();
                scanner.nextLine();
            } catch (InputMismatchException e) {
                System.out.println("Invalid input! Please enter a number from 1 to 3.");
                scanner.nextLine();
                continue;
            }
            switch (choice) {
                case 1:
                    Employee.addNewEmployee();
                    break;
                case 2:
                    Employee.listAllEmployees();
                    break;
                default:
                    System.out.println("Invalid input, please try again.");
                    break;
            }
        }
    }
    
    public static void cancelFlight(Scanner scanner) {
        java.util.List<Flight> allFlights = new java.util.ArrayList<>();
        allFlights.addAll(LocalFlight.getAllLocalFlights());
        allFlights.addAll(InternationalFlight.getAllInternationalFlights());
        
        if (allFlights.isEmpty()) {
            System.out.println("==============================================================================");
            System.out.println("                           No Flights Available To Cancel.                     ");
            System.out.println("==============================================================================");
            return;
        }
        
        System.out.println("==============================================================================");
        System.out.println("Available Flights:");
        System.out.println("==============================================================================");
        for (int i = 0; i < allFlights.size(); i++) {
            Flight flight = allFlights.get(i);
            System.out.println((i + 1) + ". " + flight.getFlightNumber() + " - from " + flight.source + " to " + flight.destination);
        }
        
        int choice = -1;
        while (true) {
            System.out.print("Enter Number Of Flight You Want To Cancel: ");
            try {
                choice = Integer.parseInt(scanner.nextLine());
                if (choice >= 1 && choice <= allFlights.size()) {
                    break;
                } else {
                    System.out.println("Invalid input. Please enter a number between 1 and " + allFlights.size());
                }
            } catch (NumberFormatException e) {
                System.out.println("Invalid input. Please enter a valid number.");
            }
        }
        
        Flight selectedFlight = allFlights.get(choice - 1);
        if (selectedFlight instanceof LocalFlight) {
            LocalFlight.getAllLocalFlights().remove(selectedFlight);
        } else if (selectedFlight instanceof InternationalFlight) {
            InternationalFlight.getAllInternationalFlights().remove(selectedFlight);
        }
        System.out.println("==============================================================================");
        System.out.println("             Flight " + selectedFlight.getFlightNumber() + " has been canceled successfully.    ");
        System.out.println("==============================================================================");
    }
}