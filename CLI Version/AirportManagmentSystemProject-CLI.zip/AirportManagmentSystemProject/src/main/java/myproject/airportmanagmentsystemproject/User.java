
package myproject.airportmanagmentsystemproject;

import java.util.Scanner;

public class User {
    protected String name;
    protected String id;
    protected String password;

    public User(boolean isPassenger) {
        this.name = inputName();
        if (!isPassenger) {
            this.id = inputId();
        }
    }
    
    public static String inputName() {
        Scanner sc = new Scanner(System.in);
        String name;
        while (true) {
            System.out.println("==================================================================================");
            System.out.println("                                    Profile                                       ");
            System.out.println("==================================================================================");
            System.out.print("Enter your Name: ");
            name = sc.nextLine().trim();
            if (name.length() >= 3 && name.matches("[a-zA-Z ]+")) {
                break;
            }
            System.out.println("Invalid input: Name must be at least 3 characters and must not contain numbers.");
        }
        return name.toUpperCase();
    }
    
    private static String inputId() {
        Scanner sc = new Scanner(System.in);
        String id;
        while (true) {
            System.out.print("Enter your id : ");
            id = sc.nextLine().trim();
            if (id.matches("\\d{10}")) { 
                break;
            }
            System.out.println("Invalid input: id must be 10 digits.");
        }
        return id;
    }
    
    public static String inputPassword() {
        Scanner sc = new Scanner(System.in);
        while (true) {
            System.out.print("Enter Password (at least 6 letters and at least 2 digits): ");
            String pwd = sc.nextLine().trim();
            int letters = 0, digits = 0;
            for (char c : pwd.toCharArray()) {
                if (Character.isLetter(c)) letters++;
                else if (Character.isDigit(c)) digits++;
            }
            if (letters >= 6 && digits >= 2) {
                return Character.toUpperCase(pwd.charAt(0)) + pwd.substring(1);
            }
            System.out.println("Error: Password must contain at least 6 letters and at least 2 digits.");
        }
    }
    
    public String getName() {
        return name;
    }
    
    public void setName(String name) {
        this.name = name;
    }
    
    public String getId() {
        return id;
    }
    
    public void setId(String id) {
        this.id = id;
    }
    
    public void displayInfo() {
        System.out.println("User Information:");
        System.out.println("Name: " + name);
        System.out.println("ID: " + id);
    }
}
